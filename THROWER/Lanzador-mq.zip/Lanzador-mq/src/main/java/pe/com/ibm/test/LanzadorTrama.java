package pe.com.ibm.test;

import pe.com.ibm.bean.ConnectionParams;
import pe.com.ibm.bean.RequestTestMQ;
import pe.com.ibm.util.UtilEnvioMQ;

/**
 * LanzadorTrama
 * @author cguerra
 **/
 public class LanzadorTrama{
 
	   /**
	    * main	
	    * IMPORTANTE: NO se deben apuntar directamente al LQ.X (COLA DE TRANSMISIÓN), ya que se BLOQUEA la QUEUE (). Los MENSAJES deben apuntar a: RQ.X ó AQ.X
	    * SI se llegara a BLOQUEAR la QUEUE, se requerirá LIMPIAR todos los mensajes dentro del: LQ.X (COLA DE TRANSMISIÓN), para que deje pasar a los MENSAJES posteriores.
	    * @param argumentos
	    **/
		public static void main( String[] argumentos ){
  
				RequestTestMQ    objRequest  = new RequestTestMQ();
				ConnectionParams objConexion = new ConnectionParams();
				UtilEnvioMQ      objEnvioMQ  = new UtilEnvioMQ();         
				long             vAleatorio  = (System.currentTimeMillis() % 1000); 
		 
				String vHost    = "srv-nodeport-mqm-server-cp4i.cluster-crga-ccc03eca20d26e6ac64511f874a64b9b-0000.us-south.containers.appdomain.cloud"; 
				int    vPuerto  = 31414; 
				String vCanal   = "CA.1";
				String vMQM     = "MQM.1";   
				String vQueue   = "AQ.2";   //OPCIONES: [AQ.1, AQ.2, RQ.1, RQ.2] 
				String vMensaje = "HOLA YO SOY TU CSM !!!!, MENSAJE #: [" + vAleatorio + "]"; 
				
				//PARAMETROS:        	
			    objConexion.setHOST( vHost );  //ROUTE 
				objConexion.setPORT( vPuerto );
				objConexion.setCHANNEL( vCanal );
				objConexion.setQMGR( vMQM );
				objConexion.setQUEUE_NAME( vQueue );
				objConexion.setUSERID( "admin" );	 
				objRequest.setActivarCertificado( false );
				objRequest.setIdTransaccion( vAleatorio + "" );
				objRequest.setMensaje( vMensaje );		
				objRequest.setConnectionParams( objConexion );  
	 
				//EJECUTAR:
				objEnvioMQ.activarCert( false ); 
				objEnvioMQ.putQueue( objRequest );
		} 
 }
 
 //El 2035 significa que la conexión llegó al oyente, encontró un canal con el nombre que se solicitó e intentó una conexión.
 
