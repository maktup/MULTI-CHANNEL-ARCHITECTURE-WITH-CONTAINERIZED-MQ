package pe.com.ibm.bean;

/**
 * cguerra
 * @author ResponseTestMQ
 **/
 public class ResponseTestMQ{
		
		private String	idTransaccion = null;
		private String	status		  = null;
	
		public String getIdTransaccion() {
			   return idTransaccion;
		}
	
		public void setIdTransaccion(String idTransaccion) {
			   this.idTransaccion = idTransaccion;
		}  
	
		public String getStatus() {
			   return status;
		}
	
		public void setStatus(String status) {
			   this.status = status;
		}
		
 }
