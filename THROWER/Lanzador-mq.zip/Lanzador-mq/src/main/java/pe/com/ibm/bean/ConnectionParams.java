package pe.com.ibm.bean;

/**
 * ConnectionParams
 * @author cguerra
 **/
 public class ConnectionParams{
		
		private String	HOST	   = null;
		private int		PORT	   = 0;
		private String	CHANNEL	   = null;
		private String	QMGR	   = null;
		private String	QUEUE_NAME = null;
		private String	USERID	   = null;
	
		public String getHOST() {
			   return HOST;
		}
	
		public void setHOST(String hOST) {
			   HOST = hOST;
		}
	
		public int getPORT() {
			   return PORT;
		}
	
		public void setPORT(int pORT) {
			   PORT = pORT;
		}
	
		public String getCHANNEL() {
			   return CHANNEL;
		}
	
		public void setCHANNEL(String cHANNEL) {
			   CHANNEL = cHANNEL;
		}
	
		public String getQMGR() {
			   return QMGR;
		}
	
		public void setQMGR(String qMGR) {
			   QMGR = qMGR;
		}
	
		public String getQUEUE_NAME() {
			   return QUEUE_NAME;
		}
	
		public void setQUEUE_NAME(String qUEUE_NAME) {
			   QUEUE_NAME = qUEUE_NAME;
		}
	
		public String getUSERID() {
			   return USERID;
		}
	
		public void setUSERID(String uSERID) {
			   USERID = uSERID;
		}
 }
 
