package pe.com.ibm.util;

import java.io.File;
import java.io.InputStream;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.TextMessage;
import org.springframework.core.io.ClassPathResource;
import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsFactoryFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import pe.com.ibm.bean.RequestTestMQ;

/**
 * UtilEnvioMQ
 * @author cguerra
 **/
 public class UtilEnvioMQ{
	
	   /**
	    * activarCert 	
	    * @param estadoParam
	    **/
	    public void activarCert( boolean estadoParam ){ 			
			try{
				boolean activarCertificado = estadoParam;

				if( activarCertificado ){
	
					String vRutaJKS = "D:/crt/repo/clientTruststore.p12";
					File   objJKS   = new File( vRutaJKS );
	
					System.out.println( "ARCHIVO: cacerts: [" + objJKS.getAbsolutePath() + "] existe? [" + objJKS.exists() + "]");
	
					if( !objJKS.exists() ){
						System.out.println( "jks.exists: [" + objJKS.exists() + "]" );
						
						InputStream objIS   = null; 
						File        fileJKS = null;
						
						try{
							ClassPathResource classPathResource = new ClassPathResource( "cacerts" );
							
							objIS = classPathResource.getInputStream();
							fileJKS = File.createTempFile( "anyfilename", ".jks" );
							java.nio.file.Files.copy( objIS, fileJKS.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING );
						} 
						catch( Exception ex ){
							   ex.printStackTrace();
						} 
						finally{
							    objIS.close();
						}
	
						vRutaJKS = fileJKS.getPath();
	
						System.out.println( vRutaJKS + " > jks.exists: " + objJKS.exists() + " the using autogenerate cacerts" );
					}
	
					System.setProperty( "java.net.preferIPv4Stack",            "true"  );	
					System.setProperty( "com.ibm.mq.cfg.useIBMCipherMappings", "false" );
					System.setProperty( "javax.net.debug",                     "ssl:verbose" );
	
					/*				 
					  System.setProperty( "javax.net.ssl.keyStore", ruta_jks );
					  System.setProperty( "javax.net.ssl.keyStorePassword", "changeit" );
					  System.setProperty( "javax.net.ssl.trustStore", ruta_jks );
					  System.setProperty( "javax.net.ssl.trustStorePassword", "changeit" );				 
					  System.setProperty( "javax.net.debug", "ssl:record" );	
					  System.setProperty( "maven.wagon.http.ssl.insecure", "true" );
					  System.setProperty( "maven.wagon.http.ssl.allowall", "true" );	
					  System.setProperty( "com.ibm.mq.cfg.SSL.OutboundSNI", "HOSTNAME" );
					  System.setProperty( "deployment.security.SSLv2Hello", "false" );
					  System.setProperty( "deployment.security.SSLv3", "false" );
					  System.setProperty( "deployment.security.TLSv1", "false" );
					  System.setProperty( "deployment.security.TLSv1.1", "false" );
					  System.setProperty( "deployment.security.TLSv1.2", "true" );
					  System.setProperty( "deployment.security.TLSv1.3", "true" );
					  System.setProperty( "https.protocols","TLSv1.2,TLSv1.3" );
					 */
				}
			} 
			catch( Exception e ){
				   e.printStackTrace();
			}			
		}
	
	   /**
	    * putQueue	
	    * @param  objRequest
	    * @return String
	    **/
		public String putQueue( RequestTestMQ objRequest ){ 
			
			String      vCadenaMensaje      = "";  
			JMSContext  objContext          = null; 
			Destination objDestination      = null; 
			JMSProducer objProducer         = null;	
			TextMessage vMensaje            = null;
			boolean     vActivarCertificado = false;
			
			try{
				vActivarCertificado = objRequest.isActivarCertificado(); 
	
				//FACTORY: 
				JmsFactoryFactory    objJmsFactory = JmsFactoryFactory.getInstance( WMQConstants.WMQ_PROVIDER );
				JmsConnectionFactory objConFactory = objJmsFactory.createConnectionFactory();
	
				//PROPIEDADES:
				objConFactory.setStringProperty(  WMQConstants.WMQ_HOST_NAME,       objRequest.getConnectionParams().getHOST() );
				objConFactory.setIntProperty(     WMQConstants.WMQ_PORT,            objRequest.getConnectionParams().getPORT() );
				objConFactory.setStringProperty(  WMQConstants.WMQ_CHANNEL,         objRequest.getConnectionParams().getCHANNEL() );
				objConFactory.setIntProperty(     WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT );
				objConFactory.setStringProperty(  WMQConstants.WMQ_QUEUE_MANAGER,   objRequest.getConnectionParams().getQMGR() );
				objConFactory.setBooleanProperty( WMQConstants.USER_AUTHENTICATION_MQCSP, true );
	
				if( vActivarCertificado ){
					objConFactory.setStringProperty( WMQConstants.WMQ_SSL_CIPHER_SUITE, "*TLS12" );
				}
				
				objConFactory.setStringProperty( WMQConstants.WMQ_APPLICATIONNAME, "RequestorPut (JMS)" ); 
				
				//objConFactory.setStringProperty( WMQConstants.USERID,   "admin" );
				//objConFactory.setStringProperty( WMQConstants.PASSWORD, "passw0rd" );
	
				String vFactory = UtilJson.toJSon( objConFactory );
				System.out.println( "JmsConnectionFactory: \n[" + vFactory + "\n]" );
	 
				//JMS: 
				objContext     = objConFactory.createContext();
				objDestination = objContext.createQueue( "queue:///" + objRequest.getConnectionParams().getQUEUE_NAME() );	            
				vCadenaMensaje = objRequest.getMensaje(); 				
				vMensaje       = objContext.createTextMessage( vCadenaMensaje );	
				objProducer    = objContext.createProducer();
				
				objProducer.send( objDestination, vMensaje );
				System.out.println( "- MENSAJE ENVIADO: [" + vMensaje + "]" ); 
			} 
			catch( Exception e ) {
			       e.printStackTrace();				   
			}
	
			return vCadenaMensaje;
		}	

 }

 