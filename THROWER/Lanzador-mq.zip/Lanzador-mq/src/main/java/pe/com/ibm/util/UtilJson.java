package pe.com.ibm.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * cguerra
 * @author UtilJson
 **/
 public class UtilJson{
    
	/**
	 * toJSon 
	 * @param  object
	 * @return String
	 **/
	 public static String toJSon( Object object ){
		String jsonInString = null;
		
		try{
			if( object != null ){
				ObjectMapper mapper = new ObjectMapper();
				mapper.enable( SerializationFeature.INDENT_OUTPUT );
				
				//Convert object to JSON string}}
				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString( object );
			}
			else{
				 jsonInString = "No se puede convertir a JSON, el objeto es nulo";
			}
		} 
		catch( Exception e ){
			   e.printStackTrace();
		}
		
		return jsonInString;
	}
	 
 }
