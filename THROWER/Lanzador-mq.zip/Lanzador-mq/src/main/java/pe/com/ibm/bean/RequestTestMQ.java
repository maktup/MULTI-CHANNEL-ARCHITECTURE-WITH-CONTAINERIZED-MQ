package pe.com.ibm.bean;

/**
 * RequestTestMQ
 * @author cguerra
 **/
 public class RequestTestMQ{

		private ConnectionParams connectionParams   = null;
		private String           idTransaccion      = null;
		private String           mensaje            = null;
		private boolean          activarCertificado = false;
	
		public ConnectionParams getConnectionParams() {
			if( this.connectionParams == null ){
				this.connectionParams = new ConnectionParams();
			}
			return connectionParams;
		}
	
		public void setConnectionParams( ConnectionParams connectionParams ){
			   this.connectionParams = connectionParams;
		}
	
		public String getIdTransaccion() {
			   return idTransaccion;
		}
	
		public void setIdTransaccion(String idTransaccion) {
			   this.idTransaccion = idTransaccion;
		}
	
		public String getMensaje() {
			   return mensaje;
		}
	
		public void setMensaje(String mensaje) {
			   this.mensaje = mensaje;
		}
	
		public boolean isActivarCertificado() {
			   return activarCertificado;
		}
	
		public void setActivarCertificado(boolean activarCertificado) {
			   this.activarCertificado = activarCertificado;
		}
	
 }

 